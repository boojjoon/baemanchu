/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, 
  Menu, 
  ShoppingCart, 
  Star, 
  MapPin, 
  CheckCircle2, 
  ShieldCheck, 
  ChevronRight, 
  Info, 
  Search, 
  SlidersHorizontal, 
  PiggyBank, 
  PlusCircle, 
  Map as MapIcon, 
  ReceiptText, 
  User, 
  ChevronLeft,
  Lock,
  Group,
  Bike,
  Utensils,
  Handshake,
  MessageSquare
} from 'lucide-react';

import guobaorouImage from './assets/images/guobaorou_menu_1779262357292.png';
import eggFriedRiceImage from './assets/images/egg_fried_rice_menu_1779262381976.png';
import yangnyeomChickenImage from './assets/images/yangnyeom_chicken_1779262654270.png';
import garlicSoyChickenImage from './assets/images/garlic_soy_chicken_1779262673408.png';
import banbanChickenImage from './assets/images/banban_chicken_1779262691635.png';

// --- Types ---
type AppView = 'verification' | 'home' | 'menu-selection' | 'order-summary' | 'checkout' | 'matching';

interface MenuItem {
  id: string;
  name: string;
  price: number;
  description: string;
  image?: string;
  best?: boolean;
}

interface Restaurant {
  id: string;
  name: string;
  rating: number;
  reviews: string;
  distance: string;
  deliveryFee: number;
  certified: boolean;
  items: MenuItem[];
  minOrderAmount: number;
}

// --- Mock Data ---
const MALATANG_RESTAURANT: Restaurant = {
  id: 'rest-1',
  name: '마라탕 전문점',
  rating: 4.8,
  reviews: '500+',
  distance: '0.5km',
  deliveryFee: 4000,
  certified: true,
  minOrderAmount: 15000,
  items: [
    { 
      id: 'm1', 
      name: '마라탕 1인분', 
      price: 12000, 
      description: '취향대로 고르는 나만의 마라탕', 
      image: 'https://lh3.googleusercontent.com/aida/ADBb0ugxHPWqyqmbMaUtwXYsTMzPPQ0s9wHGc-SiE_aGVNvUVcroxS9B69c6N9P2QEPG883z-SBh86o8T4yJsuoj6kINK9jFhDSnzJbZUc3H6YZebXCDuzKT1afsn6Jz6ai9U3VI2p0MLuHOFIPWN-qX-Od7kyTrx6ZgeoP4oSbr05OeUNgI8z3r2Mc4Gyw64VOIY8jjr5PIxkewVolgWcA1huM2ToqyYZ9nH7EUoZhajnucQ2gfWct9w7XUgZM' 
    },
    { id: 'm2', name: '꿔바로우 (소)', price: 15000, description: '바삭하고 쫄깃한 식감', image: guobaorouImage },
    { id: 'm3', name: '계란볶음밥', price: 7000, description: '고소하고 담백한 맛', image: eggFriedRiceImage },
  ]
};

const CHICKEN_RESTAURANT: Restaurant = {
  id: 'rest-2',
  name: '바삭한 치킨 본점',
  rating: 4.8,
  reviews: '500+',
  distance: '0.8km',
  deliveryFee: 3000,
  certified: true,
  minOrderAmount: 20000,
  items: [
    { 
      id: 'c1', 
      name: '바삭한 후라이드 치킨', 
      price: 18000, 
      description: '가장 인기 있는 기본 메뉴', 
      best: true,
      image: 'https://lh3.googleusercontent.com/aida/ADBb0uhPn9a-v8uEem6utWB_QRB9x53FTKsQbPYlCSpAc1PUACvsxryBbR_mRjewuKqoZ1X4QXtCsptuKvMAOqT3pNRhC1GZ9x74zFToPF99lyJOX0jWWOz-L-xylRptjL7_8mGT55bOdqxZgZKdpOFeEB3QsglgBfAlVRpQnBbDNxV1I4qpzGzyOkorpZVBrwIol2VBCSyEd_zQt5RRxNFObMo5sRxC8P6_zVRh8alAWOmY813SQlI0SnMAstRk' 
    },
    { id: 'c2', name: '달콤매콤 양념 치킨', price: 19000, description: '입맛 당기는 특제 소스', image: yangnyeomChickenImage },
    { id: 'c3', name: '마늘 간장 치킨', price: 19000, description: '짭조름한 풍미가 일품', image: garlicSoyChickenImage },
    { id: 'c4', name: '반반 치킨', price: 19500, description: '후라이드/양념', image: banbanChickenImage },
  ]
};

// --- Components ---

const ScreenWrapper = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, x: 20 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: -20 }}
    transition={{ duration: 0.3 }}
    className="min-h-screen flex flex-col bg-surface-parchment"
  >
    {children}
  </motion.div>
);

const BottomNav = ({ active, onNavigate }: { active: string, onNavigate: (view: AppView) => void }) => (
  <nav className="fixed bottom-0 left-0 w-full bg-pure-white/90 backdrop-blur-xl border-t border-outline-variant/20 shadow-lg rounded-t-xl h-16 flex justify-around items-center px-4 z-50">
    <button 
      onClick={() => onNavigate('home')}
      className={`flex flex-col items-center gap-1 ${active === 'home' ? 'text-primary font-bold' : 'text-system-gray'}`}
    >
      <MapIcon size={24} fill={active === 'home' ? 'currentColor' : 'none'} />
      <span className="text-label-sm">홈</span>
    </button>
    <button className={`flex flex-col items-center gap-1 ${active === 'search' ? 'text-primary font-bold' : 'text-system-gray'}`}>
      <Search size={24} />
      <span className="text-label-sm">검색</span>
    </button>
    <button className={`flex flex-col items-center gap-1 ${active === 'orders' ? 'text-primary font-bold' : 'text-system-gray'}`}>
      <ReceiptText size={24} fill={active === 'orders' ? 'currentColor' : 'none'} />
      <span className="text-label-sm">주문내역</span>
    </button>
    <button className={`flex flex-col items-center gap-1 ${active === 'profile' ? 'text-primary font-bold' : 'text-system-gray'}`}>
      <User size={24} />
      <span className="text-label-sm">프로필</span>
    </button>
  </nav>
);

export default function App() {
  const [view, setView] = useState<AppView>('verification');
  const [selectedRest, setSelectedRest] = useState<Restaurant>(MALATANG_RESTAURANT);
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [email, setEmail] = useState('');
  const [codeSent, setCodeSent] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  const [withMates, setWithMates] = useState(true);

  const navigate = (newView: AppView) => {
    window.scrollTo(0, 0);
    setView(newView);
  };

  // 1. Verification Screen
  if (view === 'verification') {
    return (
      <ScreenWrapper>
        <header className="fixed top-0 left-0 w-full h-14 bg-background/80 backdrop-blur-md border-b border-outline-variant/30 flex items-center px-5 justify-between z-50">
          <ArrowLeft className="text-primary" />
          <span className="text-headline-sm text-primary font-bold">학교 이메일 인증</span>
          <div className="w-6" />
        </header>

        <main className="flex-grow pt-24 pb-12 px-5 max-w-md mx-auto w-full flex flex-col items-center">
          <div className="mb-8 bg-primary-container/10 p-5 rounded-full">
            <ShieldCheck size={48} className="text-primary-container" />
          </div>
          
          <h1 className="text-headline-lg text-on-surface mb-2 text-center">학교 이메일 인증</h1>
          <p className="text-body-md text-system-gray text-center mb-10 max-w-[280px]">
            인증된 대학생만 서비스를 이용할 수 있습니다. 수집된 이메일은 인증 목적으로만 사용됩니다.
          </p>

          <div className="w-full bg-pure-white p-6 rounded-[18px] shadow-sm border border-outline-variant/20">
            <label className="text-label-md text-system-gray mb-2 block">대학 이메일</label>
            <div className="relative flex items-center mb-2">
              <input 
                type="text" 
                placeholder="example" 
                className="w-full h-14 pl-4 pr-20 bg-surface-container-low border border-outline-variant/40 rounded-xl focus:ring-1 focus:ring-primary-container outline-none text-body-lg"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <span className="absolute right-4 text-body-lg text-primary-container font-semibold">@ac.kr</span>
            </div>
            
            <div className="flex items-center gap-1 mb-6">
              <Info size={14} className="text-system-gray" />
              <span className="text-label-sm text-system-gray">학교 도메인(@ac.kr 또는 @edu)을 사용해 주세요.</span>
            </div>

            <AnimatePresence>
              {codeSent && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-6"
                >
                  <label className="text-label-md text-system-gray mb-2 block">인증번호</label>
                  <input 
                    type="text" 
                    placeholder="6자리 인증번호" 
                    maxLength={6}
                    className="w-full h-14 pl-4 bg-surface-container-low border border-outline-variant/40 rounded-xl focus:ring-1 focus:ring-primary-container outline-none text-body-lg"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value)}
                  />
                  <p className="mt-2 text-label-sm text-primary-container">입력하신 메일로 인증번호가 전송되었습니다.</p>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="bg-surface-parchment p-4 rounded-xl flex gap-3 mb-8">
              <Lock className="text-secondary-container mt-1 shrink-0" size={20} />
              <div>
                <p className="text-label-md font-bold text-on-surface">강력한 보안 보장</p>
                <p className="text-label-sm text-system-gray leading-relaxed">
                  사용자의 이메일 데이터는 암호화되어 관리되며, 제3자에게 절대 노출되지 않습니다.
                </p>
              </div>
            </div>

            <button 
              onClick={() => {
                if (!codeSent) {
                  if (email.trim()) setCodeSent(true);
                } else {
                  if (verificationCode.length === 6) navigate('home');
                }
              }}
              className="w-full h-14 bg-primary-container text-pure-white font-headline-sm rounded-full flex items-center justify-center gap-2 hover:bg-primary-container/90 active:scale-95 transition-all shadow-md"
            >
              {!codeSent ? '인증번호 보내기' : '인증 완료하기'}
              <ChevronRight size={20} />
            </button>
          </div>

          <div className="mt-10 text-center">
            <p className="text-body-md text-system-gray mb-2">이메일이 도착하지 않았나요?</p>
            <div className="flex gap-4 justify-center">
              <button className="text-primary-container text-label-md hover:underline">스팸함 확인하기</button>
              <div className="w-px h-3 bg-outline-variant self-center" />
              <button className="text-primary-container text-label-md hover:underline">고객 센터 문의</button>
            </div>
          </div>

          <div className="mt-10 rounded-[18px] overflow-hidden h-40 w-full relative grayscale opacity-20">
            <img 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDGac6thj2cczINfTvTmXKWmVF7J3y873LkN0Ply3KSY3AWsLk-MAn7iMZIHY6eDOgLO1YUK7WQs68fZiIm-HaXNgm7Sxta8Pzp7aL9l4Bia840o4vwRqptwJPfL8eMpbIVPPtiV2HYtH1Uo7rjVhvv5KtE3308TgckNLWC78sFxtC6b9OQTAaP5MrPIW1EalVr-dE3AOjncI3j9FcbG2jrrVPcT-TfylLSydL11Tg7vPjLAqILkDXZ9mEezz6emaPLhybEUiJSFI_2" 
              className="w-full h-full object-cover"
              alt="Decorative"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-surface-parchment to-transparent" />
          </div>
        </main>
      </ScreenWrapper>
    );
  }

  // 2. Home Screen
  if (view === 'home') {
    return (
      <ScreenWrapper>
        <header className="fixed top-0 left-0 w-full h-14 bg-background/80 backdrop-blur-md border-b border-outline-variant/30 flex items-center px-5 justify-between z-50">
          <div className="flex items-center gap-3">
            <Menu className="text-primary" />
            <h1 className="text-headline-lg text-primary font-bold">메인 홈</h1>
          </div>
          <div className="w-8 h-8 rounded-full overflow-hidden border border-outline-variant">
            <img 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCHBfSBzi8wFXm9P-OEZAgJpCH_JmLt_lGmke19Lz8C3yqDV_8dXG9bmR9tKHIUb_Yaj71GRKp74T4UfxHlgDgfbQI5iI59sYrfUsOHgnQt0fi1aPLnzmw2Rf0xhio88Nj82r3rnPnec7XE_2hv1l1BdFafgBWxDKR9BipkQNkWa5yBCph35n6AYqGpoCB0WaYo_j0Y1wgvVNdNzS55bn963oyJ65N0QQx-f-A4yLRqkobu9XArhY2Z6UENTEe7HYeMyqVIj5ltU3U2" 
              className="w-full h-full object-cover" 
              alt="User"
            />
          </div>
        </header>

        <main className="flex-grow pt-14 pb-20 relative overflow-hidden h-screen pointer-events-none">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDwJuZmCzvktqnCtOyYtHq8Q9OW_4as5Z8fl-gXRM5Q7UW0Vdn5GZtABlxJvjlaJyhauwbrIY1t4ZX2GkUoGY9yYIQSBBStjFbqp2e50hoXfpLUZHcOjHBqnoN7rRtnkpLYVXJuRA_mw6rur4oN0i81J7aU7BajZNpPjVHnVNtK0CanZ6dEGMMYlwSDGirnLzAn7QQagMYxcUwfrpV1GccKyfsXZ4xX-59PmnwfFr6PcMDhQuCMHmOBmA5gzXCu75BmFg9WFgUsOfmg" 
              className="w-full h-full object-cover grayscale-[0.2] contrast-[0.9] brightness-[1.1]"
              alt="Map"
            />
            
            {/* User Location */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="w-6 h-6 bg-primary-container rounded-full border-4 border-pure-white shadow-lg relative">
                <div className="absolute inset-0 bg-primary-container rounded-full animate-ping opacity-20" />
              </div>
            </div>

            {/* Pins */}
            <motion.div 
              onClick={() => { setSelectedRest(MALATANG_RESTAURANT); navigate('menu-selection'); }}
              initial={{ scale: 0 }} animate={{ scale: 1 }}
              className="absolute top-[38%] left-[25%] pointer-events-auto cursor-pointer"
            >
              <div className="bg-pure-white rounded-xl p-3 shadow-lg border border-outline-variant/20 min-w-[150px]">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-headline-sm text-on-surface">마라탕</span>
                  <span className="bg-secondary-container/10 text-secondary-container px-2 py-0.5 rounded-full text-label-sm font-bold">3,500원 남음</span>
                </div>
                <div className="flex items-center gap-2">
                   <div className="flex -space-x-1">
                      <div className="w-6 h-6 rounded-full bg-surface-container-high border border-pure-white" />
                      <div className="w-6 h-6 rounded-full bg-surface-container-high border border-pure-white" />
                   </div>
                   <span className="text-system-gray text-label-md">2명 대기중</span>
                </div>
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-pure-white rotate-45 border-r border-b border-outline-variant/20" />
              </div>
            </motion.div>

            <motion.div 
              onClick={() => { setSelectedRest(CHICKEN_RESTAURANT); navigate('menu-selection'); }}
              initial={{ scale: 0 }} animate={{ scale: 1 }} delay={0.2}
              className="absolute top-[62%] left-[55%] pointer-events-auto cursor-pointer"
            >
              <div className="bg-pure-white rounded-xl p-3 shadow-lg border border-outline-variant/20 min-w-[150px]">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-headline-sm text-on-surface">치킨</span>
                  <span className="bg-secondary-container/10 text-secondary-container px-2 py-0.5 rounded-full text-label-sm font-bold">8,000원 남음</span>
                </div>
                <div className="flex items-center gap-2">
                   <div className="w-6 h-6 rounded-full bg-surface-container-high border border-pure-white" />
                   <span className="text-system-gray text-label-md">1명 대기중</span>
                </div>
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-pure-white rotate-45 border-r border-b border-outline-variant/20" />
              </div>
            </motion.div>
          </div>

          <div className="relative z-10 px-5 mt-4 pointer-events-auto">
            <div className="bg-pure-white/90 backdrop-blur-md h-12 rounded-full px-5 flex items-center shadow-lg border border-outline-variant/20">
              <Search className="text-system-gray mr-3" size={20} />
              <input type="text" placeholder="어떤 음식을 같이 먹을까요?" className="bg-transparent border-none focus:ring-0 w-full text-body-md" />
              <SlidersHorizontal className="text-primary ml-2" size={20} />
            </div>
          </div>

          <div className="absolute top-32 right-5 pointer-events-auto">
            <div className="bg-pure-white rounded-full pl-2 pr-4 py-1.5 flex items-center gap-2 shadow-lg border border-outline-variant/10">
              <div className="w-7 h-7 bg-tertiary-fixed rounded-full flex items-center justify-center">
                <PiggyBank size={16} className="text-tertiary" />
              </div>
              <span className="text-label-md font-medium text-on-surface">이번 달 <span className="text-tertiary font-bold">12,400원</span> 절약</span>
            </div>
          </div>

          <div className="absolute bottom-6 right-5 pointer-events-auto">
            <button className="bg-primary-container text-pure-white rounded-full px-6 py-4 flex items-center gap-2 shadow-2xl active:scale-95 transition-transform">
              <PlusCircle size={20} />
              <span className="text-body-lg font-bold">새로운 모집 시작하기</span>
            </button>
          </div>
        </main>
        <BottomNav active="home" onNavigate={navigate} />
      </ScreenWrapper>
    );
  }

  // 3. Menu Selection Screen
  if (view === 'menu-selection') {
    return (
      <ScreenWrapper>
        <header className="sticky top-0 w-full h-14 bg-pure-white border-b border-surface-container-highest flex items-center justify-between px-5 z-50">
          <div className="flex items-center gap-2">
            <button onClick={() => navigate('home')} className="hover:opacity-80"><ArrowLeft className="text-primary" size={24} /></button>
            <h1 className="text-headline-sm text-primary">{selectedRest.name} 메뉴 선택</h1>
          </div>
          <button className="hover:opacity-80"><ShoppingCart className="text-primary" size={24} /></button>
        </header>

        <main className="flex-grow pt-4 pb-48 px-5 flex flex-col gap-6">
          <section className="bg-pure-white p-5 rounded-xl border border-surface-container-highest flex flex-col gap-3">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-headline-sm text-on-surface">{selectedRest.name}</h2>
                  {selectedRest.certified && (
                    <span className="bg-[#ECFDF5] text-safe-green text-label-sm font-bold px-2 py-0.5 rounded-full border border-[#D1FAE5] flex items-center gap-1">
                      <CheckCircle2 size={12} />
                      학교 인증 완료
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-system-gray text-label-md">
                  <div className="flex items-center text-[#FBBF24]">
                    <Star size={16} fill="currentColor" />
                    <span className="ml-0.5 text-on-surface font-semibold">{selectedRest.rating}</span>
                  </div>
                  <div className="w-px h-3 bg-outline-variant" />
                  <span>{selectedRest.distance}</span>
                  <div className="w-px h-3 bg-outline-variant" />
                  <span>배달비 {selectedRest.deliveryFee.toLocaleString()}원</span>
                </div>
              </div>
            </div>
          </section>

          <section className="flex flex-col gap-4">
            <h3 className="text-headline-sm text-on-surface">메인 메뉴</h3>
            {selectedRest.items.map((item) => (
              <label 
                key={item.id}
                onClick={() => { setSelectedItem(item); setQuantity(1); }}
                className={`bg-pure-white p-4 rounded-xl border-2 transition-all cursor-pointer flex gap-4 ${selectedItem?.id === item.id ? 'border-primary' : 'border-surface-container-highest'}`}
              >
                <input type="radio" name="menu" className="hidden" checked={selectedItem?.id === item.id} readOnly />
                <div className="flex-grow">
                  <div className="flex items-center gap-2 mb-1">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${selectedItem?.id === item.id ? 'border-primary' : 'border-outline'}`}>
                      {selectedItem?.id === item.id && <div className="w-2.5 h-2.5 rounded-full bg-primary" />}
                    </div>
                    <h4 className="text-body-lg font-semibold">{item.name}</h4>
                  </div>
                  <p className="text-body-md text-system-gray mb-3">{item.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-headline-sm text-on-surface font-bold">{item.price.toLocaleString()}원</span>
                    {item.best && <span className="bg-secondary/10 text-secondary px-2 py-0.5 rounded text-label-sm font-bold uppercase">BEST</span>}
                  </div>
                </div>
                {item.image && (
                  <div className="w-24 h-24 rounded-lg overflow-hidden shrink-0">
                    <img src={item.image} className="w-full h-full object-cover" alt={item.name} />
                  </div>
                )}
              </label>
            ))}
          </section>
        </main>

        <AnimatePresence>
          {selectedItem && (
            <motion.div 
              initial={{ y: 100 }} 
              animate={{ y: 0 }} 
              exit={{ y: 100 }}
              className="fixed bottom-0 left-0 right-0 bg-pure-white border-t border-surface-container-highest p-5 z-50 rounded-t-2xl shadow-[0_-4px_20px_rgba(0,0,0,0.1)] max-w-xl mx-auto"
            >
              <div className="bg-[#FFF7ED] p-3 rounded-lg flex items-center gap-2 mb-4 border border-[#FFEDD5]">
                <PiggyBank className="text-savings-orange" size={20} fill="currentColor" />
                <p className="text-savings-orange text-label-md font-medium">
                  메이트와 함께 주문하면 <span className="font-bold">최대 2,500원</span> 절약 가능!
                </p>
              </div>

              <div className="flex items-center justify-between mb-5">
                <span className="text-headline-sm">수량</span>
                <div className="flex items-center border border-surface-container-highest rounded-full px-1 py-1">
                  <button 
                    onClick={() => setQuantity(q => Math.max(1, q - 1))}
                    className="w-10 h-10 flex items-center justify-center text-outline hover:text-on-surface"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  <span className="w-12 text-center text-headline-sm">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(q => q + 1)}
                    className="w-10 h-10 flex items-center justify-center text-primary-container"
                  >
                    <ChevronRight size={20} />
                  </button>
                </div>
              </div>

              <button 
                onClick={() => navigate('order-summary')}
                className="w-full h-14 bg-primary-container text-pure-white rounded-xl text-headline-sm font-bold flex items-center justify-center shadow-lg active:scale-95 transition-all"
              >
                {(selectedItem.price * quantity).toLocaleString()}원 담기
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </ScreenWrapper>
    );
  }

  // 4. Order Summary Screen
  if (view === 'order-summary') {
    const itemPrice = selectedItem?.price || selectedRest.items[0].price;
    const userOrderAmount = itemPrice * quantity;
    const minOrderAmount = selectedRest.minOrderAmount;

    // Define other mates' mock orders to simulate joint matching
    const matesOrders = selectedRest.id === 'rest-1'
      ? [
          { name: '이대학', menuItem: '마라탕 1인분', price: 12000, dept: '공과대학' },
          { name: '김공대', menuItem: '계란볶음밥', price: 7000, dept: '공과대학' }
        ]
      : [
          { name: '이대학', menuItem: '바삭한 후라이드 치킨', price: 18000, dept: '공과대학' },
          { name: '김공대', menuItem: '달콤매콤 양념 치킨', price: 19000, dept: '공과대학' }
        ];

    const matesTotal = matesOrders.reduce((sum, o) => sum + o.price, 0);
    const totalOrderAmount = withMates ? (userOrderAmount + matesTotal) : userOrderAmount;
    const isFulfilling = totalOrderAmount >= minOrderAmount;
    const amountNeeded = minOrderAmount - totalOrderAmount;
    const percentage = Math.min(100, Math.round((totalOrderAmount / minOrderAmount) * 100));

    return (
       <ScreenWrapper>
        <header className="fixed top-0 left-0 w-full h-14 bg-background/80 backdrop-blur-md border-b border-outline-variant/30 flex items-center px-5 justify-between z-50">
          <button onClick={() => navigate('menu-selection')} className="hover:opacity-80"><ArrowLeft className="text-primary" size={24} /></button>
          <h1 className="text-headline-lg text-primary font-bold">배만추</h1>
          <div className="w-8 h-8 rounded-full overflow-hidden border border-outline-variant">
            <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuCHBfSBzi8wFXm9P-OEZAgJpCH_JmLt_lGmke19Lz8C3yqDV_8dXG9bmR9tKHIUb_Yaj71GRKp74T4UfxHlgDgfbQI5iI59sYrfUsOHgnQt0fi1aPLnzmw2Rf0xhio88Nj82r3rnPnec7XE_2hv1l1BdFafgBWxDKR9BipkQNkWa5yBCph35n6AYqGpoCB0WaYo_j0Y1wgvVNdNzS55bn963oyJ65N0QQx-f-A4yLRqkobu9XArhY2Z6UENTEe7HYeMyqVIj5ltU3U2" className="w-full h-full object-cover" alt="User" />
          </div>
        </header>

        <main className="mt-14 pb-32 max-w-2xl mx-auto w-full px-5 flex flex-col gap-6">
          <div className="pt-4">
            {/* Interactive Mode Selector */}
            <div className="flex bg-surface-container-low rounded-xl p-1 mb-2 border border-outline-variant/20 shadow-inner">
              <button 
                onClick={() => setWithMates(true)} 
                className={`flex-1 py-2 text-label-sm font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${withMates ? 'bg-pure-white text-primary shadow-sm border border-outline-variant/10' : 'text-system-gray hover:text-on-surface'}`}
              >
                <Group size={16} fill="currentColor" />
                공동 배달 (메이트 참여 완료)
              </button>
              <button 
                onClick={() => setWithMates(false)} 
                className={`flex-1 py-2 text-label-sm font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${!withMates ? 'bg-pure-white text-primary shadow-sm border border-outline-variant/10' : 'text-system-gray hover:text-on-surface'}`}
              >
                <User size={16} />
                나 혼자 채우기
              </button>
            </div>

            {/* Dynamic Progress indicator */}
            <div className={`rounded-xl p-5 shadow-sm border transition-all ${isFulfilling ? 'bg-emerald-50/50 border-emerald-500/15' : 'bg-pure-white border-outline-variant/10'}`}>
              <div className="flex justify-between items-center mb-2">
                <span className={`text-label-md font-semibold ${isFulfilling ? 'text-emerald-700 font-bold' : 'text-on-surface'}`}>
                  {isFulfilling 
                    ? (withMates ? '🎉 메이트 동참으로 최소주문금액 충족 완료!' : '✨ 최소주문금액 충족 완료!') 
                    : `최소주문금액까지 ${amountNeeded.toLocaleString()}원 남음`}
                </span>
                <span className={`text-label-md font-bold ${isFulfilling ? 'text-emerald-600' : 'text-savings-orange'}`}>
                  {percentage}%
                </span>
              </div>
              <div className="h-2 w-full bg-surface-container rounded-full overflow-hidden mb-1.5">
                <motion.div 
                  initial={{ width: 0 }} 
                  animate={{ width: `${percentage}%` }} 
                  className={`h-full rounded-full transition-colors ${isFulfilling ? 'bg-emerald-500' : 'bg-savings-orange'}`} 
                />
              </div>
              <div className="flex flex-col gap-0.5 text-[11px] text-system-gray">
                <p>
                  {selectedRest.name} 최소주문금액: <span className="font-semibold text-on-surface">{minOrderAmount.toLocaleString()}원</span>
                </p>
                <p>
                  현재 담긴 총액: <span className="font-semibold text-primary">{totalOrderAmount.toLocaleString()}원</span> 
                  {withMates && ` (나의 주문: ${userOrderAmount.toLocaleString()}원 + 메이트 주문: ${matesTotal.toLocaleString()}원)`}
                </p>
              </div>
            </div>
          </div>

          <section className="bg-pure-white rounded-xl p-6 border border-outline-variant/10">
            <h3 className="text-headline-sm text-on-surface mb-4">나의 주문 내역</h3>
            <div className="flex justify-between items-center pb-4 border-b border-outline-variant/10">
              <div className="flex gap-4 items-center">
                <div className="w-20 h-20 rounded-lg overflow-hidden shrink-0">
                  <img src={selectedItem?.image || selectedRest.items[0].image} className="w-full h-full object-cover" alt="Item" />
                </div>
                <div>
                  <p className="text-body-lg font-semibold">{selectedItem?.name || selectedRest.items[0].name}</p>
                  <p className="text-label-md text-on-surface-variant">수량: {quantity}개</p>
                </div>
              </div>
              <span className="text-body-lg font-bold text-on-surface">{(userOrderAmount).toLocaleString()}원</span>
            </div>
            
            <div className="mt-4 p-4 bg-secondary-container/5 rounded-xl flex items-center gap-3">
              <PiggyBank className="text-secondary-container" size={24} fill="currentColor" />
              <div>
                <p className="text-label-md font-bold text-secondary-container">공동 배달 혜택</p>
                <p className="text-label-sm text-on-surface-variant">배달비 1,400원 절감됨</p>
              </div>
            </div>
          </section>

          <section className="bg-pure-white rounded-xl overflow-hidden border border-outline-variant/10">
             <div className="p-6 bg-primary-container/5">
                <h3 className="text-headline-sm text-primary font-bold">최종 정산 금액 (나의 몫)</h3>
             </div>
             <div className="p-6 space-y-4">
                <div className="flex justify-between items-center">
                   <span className="text-body-lg text-on-surface-variant">나의 결제 예정 금액</span>
                   <span className="text-headline-md text-primary-container font-bold">{(userOrderAmount + 1400).toLocaleString()}원</span>
                </div>
                <div className="bg-surface-container-low p-4 rounded-xl flex items-center gap-3">
                   <Info className="text-primary-container" size={20} />
                   <p className="text-label-md text-on-surface-variant font-medium">공과대학 픽업지에서 공동 수령</p>
                </div>
             </div>
          </section>

          <section className="bg-pure-white rounded-xl p-6 border border-outline-variant/10">
            <h4 className="text-label-sm text-system-gray uppercase tracking-widest mb-4">함께하는 공동 장바구니</h4>
            <div className="space-y-4">
              {/* My Order status row */}
              <div className="flex items-center gap-4 p-3 bg-primary-container/5 rounded-xl border border-primary-container/20">
                <div className="h-10 w-10 rounded-full bg-primary-container flex items-center justify-center font-bold text-pure-white shrink-0">나</div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <span className="text-body-md font-bold text-primary-container">나 (User)</span>
                    <span className="px-2 py-0.5 bg-primary-container text-pure-white rounded-full text-[9px] font-bold">참여 완료</span>
                  </div>
                  <div className="flex justify-between items-center mt-1">
                    <p className="text-label-sm text-on-surface-variant">{selectedItem?.name || selectedRest.items[0].name} ({quantity}개)</p>
                    <p className="text-label-sm font-bold text-on-surface">{userOrderAmount.toLocaleString()}원</p>
                  </div>
                </div>
              </div>

              {/* Other Mates list dynamically simulated */}
              {withMates ? (
                matesOrders.map((mate) => (
                  <div key={mate.name} className="flex items-center gap-4 p-3 bg-surface-container-lowest rounded-xl border border-outline-variant/10">
                    <div className="h-10 w-10 rounded-full bg-surface-container flex items-center justify-center font-bold text-on-surface-variant shrink-0">
                      {mate.name[0]}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-2">
                          <span className="text-body-md font-semibold">{mate.name}</span>
                          <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-[10px] font-bold">학교 인증 완료</span>
                        </div>
                        <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-full text-[9px] font-bold">메뉴 결정 완료</span>
                      </div>
                      <div className="flex justify-between items-center mt-1">
                        <p className="text-label-sm text-on-surface-variant">{mate.menuItem}</p>
                        <p className="text-label-sm font-bold text-on-surface">{mate.price.toLocaleString()}원</p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-4 text-center text-label-md text-system-gray bg-surface-container-lowest rounded-xl border border-dashed border-outline-variant">
                  다른 공동 메이트들이 참여하기를 기다리고 있습니다.
                </div>
              )}
            </div>
            
            <div className="mt-6 pt-4 border-t border-outline-variant/10 flex justify-center items-center gap-2 font-medium text-body-md">
              <Group className="text-primary-container" size={18} fill="currentColor" />
              <span>{withMates ? '3명의 메이트 모집 및 메뉴 선택 완료!' : '메이트들이 모집 참여 대기 중...'}</span>
            </div>
          </section>
        </main>

        <div className="fixed bottom-16 left-0 w-full p-5 bg-white/80 backdrop-blur-md border-t border-outline-variant/20 z-40">
           {isFulfilling ? (
             <button 
              onClick={() => navigate('checkout')}
              className="w-full h-14 bg-primary-container text-pure-white font-bold text-body-lg rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-all max-w-xl mx-auto"
             >
              결제하기
             </button>
           ) : (
             <div className="flex flex-col gap-2 max-w-xl mx-auto">
               <p className="text-center text-label-sm text-savings-orange font-bold flex items-center justify-center gap-1 bg-savings-orange/5 py-1.5 rounded-lg border border-savings-orange/15">
                 ⚠️ 최소주문금액({minOrderAmount.toLocaleString()}원)을 충족해야 결제할 수 있습니다.
               </p>
               <button 
                onClick={() => navigate('menu-selection')}
                className="w-full h-14 bg-system-gray/20 text-system-gray font-bold text-body-lg rounded-full flex items-center justify-center hover:bg-system-gray/25 transition-all"
               >
                결제하기 (메뉴 추가/변경하기)
               </button>
             </div>
           )}
        </div>
        <BottomNav active="orders" onNavigate={navigate} />
      </ScreenWrapper>
    );
  }

  // 5. Checkout Screen
  if (view === 'checkout') {
     return (
       <ScreenWrapper>
        <header className="fixed top-0 left-0 w-full h-14 bg-background/80 backdrop-blur-md border-b border-outline-variant/30 flex items-center px-5 z-50">
          <button onClick={() => navigate('order-summary')} className="hover:opacity-80"><ArrowLeft className="text-primary" size={24} /></button>
          <h1 className="text-headline-sm flex-1 text-center pr-8">결제하기</h1>
        </header>

        <main className="mt-14 pb-28 px-5 py-6 flex flex-col gap-6 max-w-md mx-auto w-full">
          <section className="bg-pure-white rounded-xl p-6 shadow-sm border border-outline-variant/20">
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-headline-sm">주문 요약</h2>
              <span className="text-label-md px-2 py-0.5 bg-surface-container text-on-surface-variant rounded-lg">3명 모집완료</span>
            </div>
            <div className="space-y-3 mb-6">
              <div className="flex justify-between items-center text-body-md">
                <span>{selectedItem?.name || selectedRest.items[0].name}</span>
                <span>{((selectedItem?.price || selectedRest.items[0].price) * quantity).toLocaleString()}원</span>
              </div>
              <div className="flex justify-between items-center text-body-md">
                <div className="flex items-center gap-1">
                  <span className="text-on-surface-variant">배달비 (1/N)</span>
                  <span className="text-label-sm text-system-gray">(총 4,200원)</span>
                </div>
                <span>1,400원</span>
              </div>
            </div>
            
            <div className="p-4 bg-savings-orange/10 rounded-xl flex items-center gap-3 mb-6 border border-savings-orange/10">
              <PiggyBank className="text-savings-orange" size={24} fill="currentColor" />
              <p className="text-label-md text-savings-orange font-bold">
                함께 주문하여 배달비 2,800원을 절약했어요!
              </p>
            </div>

            <div className="pt-4 border-t border-outline-variant/20 flex justify-between items-center">
              <span className="text-headline-sm">최종 결제 금액</span>
              <span className="text-headline-md text-primary-container font-bold">{((selectedItem?.price || 0) * quantity + 1400).toLocaleString()}원</span>
            </div>
          </section>

          <section className="bg-pure-white rounded-xl p-6 shadow-sm border border-outline-variant/20">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-label-sm text-system-gray uppercase tracking-widest">배달 장소</h2>
              <button className="text-label-md text-primary-container font-bold">변경</button>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-surface-container rounded-full flex items-center justify-center">
                <MapPin className="text-on-surface-variant" size={20} />
              </div>
              <div>
                <p className="text-body-lg font-semibold">공과대학 제1공학관 앞</p>
                <p className="text-body-md text-system-gray">서울대학교 관악캠퍼스</p>
              </div>
            </div>
          </section>

          <section className="bg-pure-white rounded-xl p-6 shadow-sm border border-outline-variant/20">
            <h2 className="text-label-sm text-system-gray uppercase tracking-widest mb-4">결제 수단</h2>
            <div className="space-y-2">
              <label className="flex items-center p-4 rounded-xl border border-outline-variant/30 hover:bg-surface-container-low cursor-pointer transition-colors transition-all active:scale-[0.98]">
                <div className="w-8 h-8 rounded-lg bg-[#FEE500] flex items-center justify-center mr-3 font-bold text-[10px]">PAY</div>
                <span className="text-body-md flex-1 font-medium">카카오페이</span>
                <div className="w-5 h-5 rounded-full border-2 border-outline" />
              </label>
              <label className="flex items-center p-4 rounded-xl border border-outline-variant/30 hover:bg-surface-container-low cursor-pointer transition-colors transition-all active:scale-[0.98]">
                <div className="w-8 h-8 rounded-lg bg-[#03C75A] flex items-center justify-center mr-3 font-bold text-[10px] text-white">N Pay</div>
                <span className="text-body-md flex-1 font-medium">네이버페이</span>
                <div className="w-5 h-5 rounded-full border-2 border-outline-variant" />
              </label>
            </div>
          </section>

          <div className="w-full h-48 rounded-[18px] overflow-hidden relative shadow-lg">
             <img 
              src={selectedItem?.image || selectedRest.items[0].image} 
              className="w-full h-full object-cover" 
              alt={selectedItem?.name || selectedRest.name}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-5">
              <p className="text-pure-white text-label-md font-medium">따뜻한 상태로 공과대학 입구에서 만나요!</p>
            </div>
          </div>
        </main>

        <footer className="fixed bottom-0 left-0 w-full p-5 bg-pure-white/95 backdrop-blur-xl border-t border-outline-variant/20 z-50">
          <button 
            onClick={() => navigate('matching')}
            className="w-full h-14 bg-primary-container text-pure-white rounded-full font-bold text-body-lg shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <span>{((selectedItem?.price || 0) * quantity + 1400).toLocaleString()}원 결제하기</span>
            <Lock size={18} />
          </button>
        </footer>
      </ScreenWrapper>
     );
  }

  // 6. Matching Screen (C-1)
  if (view === 'matching') {
    return (
      <ScreenWrapper>
        <header className="fixed top-0 left-0 w-full h-14 bg-background/80 backdrop-blur-md border-b border-outline-variant/30 flex items-center px-5 justify-between z-50">
          <div className="flex items-center gap-3">
             <Menu className="text-primary" />
          </div>
          <h1 className="text-headline-lg text-primary font-bold">배만추</h1>
          <div className="w-8 h-8 rounded-full overflow-hidden border border-outline-variant shadow-sm">
             <User className="text-system-gray" />
          </div>
        </header>

        <main className="pt-14 pb-24">
          <div className="px-5 pt-4 pb-2">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-surface-container text-system-gray border border-outline-variant/30 uppercase tracking-tighter">
              매칭 완료 및 픽업 스팟 안내
            </span>
          </div>

          <section className="px-5 py-8 bg-pure-white">
            <div className="flex items-center gap-2 mb-3">
              <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-safe-green text-white">
                <CheckCircle2 size={16} />
              </div>
              <span className="text-label-md text-safe-green font-bold uppercase">매칭 완료</span>
            </div>
            <h2 className="text-headline-md text-on-surface mb-6 leading-tight">모두가 3분 안에 도착할 수 있는 안전한 픽업 스팟이에요.</h2>
            
            <div className="flex items-center gap-4 p-4 bg-surface-container-low rounded-[18px] border border-outline-variant/20">
              <div className="w-12 h-12 rounded-xl bg-primary-fixed flex items-center justify-center shadow-inner">
                <PiggyBank className="text-on-primary-fixed-variant" size={24} fill="currentColor" />
              </div>
              <div>
                <p className="text-label-sm text-system-gray">절약 확정 금액</p>
                <p className="text-headline-sm text-primary font-bold">₩4,200 절약 확정</p>
              </div>
            </div>
          </section>

          <section className="relative w-full h-[420px] overflow-hidden shadow-inner">
             {/* Map Placeholder */}
             <div className="absolute inset-0">
                <img 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDwJuZmCzvktqnCtOyYtHq8Q9OW_4as5Z8fl-gXRM5Q7UW0Vdn5GZtABlxJvjlaJyhauwbrIY1t4ZX2GkUoGY9yYIQSBBStjFbqp2e50hoXfpLUZHcOjHBqnoN7rRtnkpLYVXJuRA_mw6rur4oN0i81J7aU7BajZNpPjVHnVNtK0CanZ6dEGMMYlwSDGirnLzAn7QQagMYxcUwfrpV1GccKyfsXZ4xX-59PmnwfFr6PcMDhQuCMHmOBmA5gzXCu75BmFg9WFgUsOfmg"
                  className="w-full h-full object-cover opacity-100"
                  alt="Track Map"
                />
             </div>
             
             <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative">
                  <div className="bg-pure-white px-5 py-2.5 rounded-full shadow-2xl border-2 border-safe-green mb-3 flex items-center gap-2 transform -translate-y-4">
                    <MapPin className="text-safe-green" size={20} fill="currentColor" />
                    <span className="text-headline-sm text-on-surface font-bold">Safe Spot: 제1학생회관 앞</span>
                  </div>
                  <div className="w-10 h-10 bg-safe-green/20 rounded-full flex items-center justify-center mx-auto">
                    <div className="w-5 h-5 bg-safe-green rounded-full border-4 border-pure-white shadow-lg" />
                  </div>
                </div>
             </div>

             <div className="absolute bottom-6 left-6 right-6">
               <div className="bg-pure-white rounded-2xl p-4 shadow-2xl border border-outline-variant/10">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-body-md font-bold">실시간 배달 현황</span>
                    <span className="text-label-sm text-primary font-bold">12분 후 도착 예정</span>
                  </div>
                  <div className="h-2 bg-surface-container rounded-full overflow-hidden mb-4 relative">
                    <motion.div initial={{ width: 0 }} animate={{ width: '65%' }} className="h-full bg-primary-container rounded-full" />
                  </div>
                  <div className="flex justify-between text-system-gray">
                    <div className="flex flex-col items-center gap-0.5">
                      <Utensils size={18} className="text-primary-container" fill="currentColor" />
                      <span className="text-[10px] font-medium">준비중</span>
                    </div>
                    <div className="flex flex-col items-center gap-0.5 text-primary-container">
                      <Bike size={18} className="text-primary-container" />
                      <span className="text-[10px] font-bold">배달중</span>
                    </div>
                    <div className="flex flex-col items-center gap-0.5">
                      <Handshake size={18} />
                      <span className="text-[10px] font-medium">픽업대기</span>
                    </div>
                  </div>
               </div>
             </div>
          </section>

          <section className="px-5 mt-10">
            <h3 className="text-headline-sm text-on-surface mb-4 font-bold">함께하는 메이트</h3>
            <div className="flex flex-col gap-3">
              {[
                { name: '김*준 (컴공과)', temp: '42.5℃', rating: 4.9 },
                { name: '이*연 (경영학과)', temp: '45.0℃', rating: 5.0 },
              ].map((mate, i) => (
                <div key={mate.name} className="flex items-center justify-between p-4 bg-pure-white rounded-2xl border border-outline-variant/20 shadow-sm">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-full bg-surface-container shrink-0 border-2 border-outline-variant/10" />
                    <div>
                      <p className="text-body-lg font-bold text-on-surface">{mate.name}</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <Star className="text-[#FBBF24]" size={14} fill="currentColor" />
                        <span className="text-label-md text-system-gray">{mate.rating} · 매너온도 {mate.temp}</span>
                      </div>
                    </div>
                  </div>
                  <button className="px-4 py-2 bg-surface-container rounded-full text-label-md text-primary font-bold flex items-center gap-1.5 hover:bg-surface-container-high transition-all">
                    <MessageSquare size={14} />
                    채팅하기
                  </button>
                </div>
              ))}
            </div>
          </section>

          <section className="px-5 mt-10 mb-12">
            <div className="p-6 bg-primary/5 rounded-[22px] border border-primary/10">
              <div className="flex items-center gap-2 mb-4">
                <ShieldCheck size={20} className="text-primary" fill="currentColor" />
                <h4 className="text-headline-sm text-primary font-bold">안전한 픽업을 위해</h4>
              </div>
              <ul className="space-y-4">
                <li className="flex gap-3 text-on-surface-variant text-body-md">
                   <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2" />
                   <p>픽업 스팟은 가로등이 밝고 유동 인구가 많은 곳으로 지정되었습니다.</p>
                </li>
                <li className="flex gap-3 text-on-surface-variant text-body-md">
                   <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2" />
                   <p>음식을 받으신 후 꼭 앱에서 '수령 완료'를 눌러주세요.</p>
                </li>
                <li className="flex gap-3 text-on-surface-variant text-body-md">
                   <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2" />
                   <p>메이트와의 매너 있는 인사가 더 나은 커뮤니티를 만듭니다.</p>
                </li>
              </ul>
            </div>
          </section>
        </main>
        <BottomNav active="orders" onNavigate={navigate} />
      </ScreenWrapper>
    );
  }

  return (
    <div className="flex items-center justify-center h-screen">
      <p>Loading app...</p>
    </div>
  );
}

